import discord
from discord.ext import commands, tasks
from discord import app_commands
from dotenv import load_dotenv
import os
import json
from datetime import datetime, timedelta
import random

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

DB_FILE = "database.json"

# ================= BANCO =================
def load_db():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "w") as f:
            json.dump({}, f)
    with open(DB_FILE, "r") as f:
        return json.load(f)

def save_db(data):
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=4)

# ================= VIEW PARTICIPAR =================
class JoinView(discord.ui.View):
    def __init__(self, message_id):
        super().__init__(timeout=None)
        self.message_id = str(message_id)

    @discord.ui.button(label="🎉 Participar", style=discord.ButtonStyle.green)
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        db = load_db()
        giveaway = db.get(self.message_id)

        if not giveaway:
            return await interaction.response.send_message("Sorteio não encontrado.", ephemeral=True)

        user_id = str(interaction.user.id)

        if user_id in giveaway["participants"]:
            return await interaction.response.send_message("Você já participou!", ephemeral=True)

        giveaway["participants"].append(user_id)
        save_db(db)

        await interaction.response.send_message("Você entrou no sorteio!", ephemeral=True)

# ================= VIEW FINAL =================
class EndView(discord.ui.View):
    def __init__(self, message_id):
        super().__init__(timeout=None)
        self.message_id = str(message_id)

    @discord.ui.button(label="🔄 Resortear", style=discord.ButtonStyle.blurple)
    async def reroll(self, interaction: discord.Interaction, button: discord.ui.Button):
        db = load_db()
        giveaway = db.get(self.message_id)

        if not giveaway:
            return await interaction.response.send_message("Erro no sorteio.", ephemeral=True)

        participants = giveaway["participants"]
        winners_count = giveaway["winners"]

        if len(participants) < 1:
            return await interaction.response.send_message("Sem participantes.", ephemeral=True)

        winners = random.sample(participants, min(len(participants), winners_count))

        mention = ", ".join([f"<@{w}>" for w in winners])

        await interaction.response.send_message(f"🎉 Novo(s) vencedor(es): {mention}")

# ================= MODAL =================
class GiveawayModal(discord.ui.Modal, title="Configurar Sorteio"):

    nome = discord.ui.TextInput(label="Nome do sorteio", style=discord.TextStyle.short)
    regras = discord.ui.TextInput(label="Regras", style=discord.TextStyle.paragraph)
    premio = discord.ui.TextInput(label="Prêmio(s)", style=discord.TextStyle.paragraph)
    dias = discord.ui.TextInput(label="Dias até o sorteio", style=discord.TextStyle.short)
    ganhadores = discord.ui.TextInput(label="Quantidade de ganhadores", style=discord.TextStyle.short)

    async def on_submit(self, interaction: discord.Interaction):
        dias = int(self.dias.value)
        ganhadores = int(self.ganhadores.value)

        end_time = datetime.utcnow() + timedelta(days=dias)

        embed = discord.Embed(
            title=f"🎉 {self.nome.value}",
            description=f"{self.premio.value}",
            color=discord.Color.blue()
        )

        embed.add_field(name="📜 Regras", value=self.regras.value, inline=False)
        embed.add_field(name="⏳ Termina em", value=f"<t:{int(end_time.timestamp())}:R>")
        embed.add_field(name="🏆 Ganhadores", value=str(ganhadores))

        view = discord.ui.View()

        async def start_callback(i: discord.Interaction):
            msg = i.message

            db = load_db()
            db[str(msg.id)] = {
                "end_time": end_time.timestamp(),
                "participants": [],
                "winners": ganhadores,
                "ended": False
            }
            save_db(db)

            await msg.edit(view=JoinView(msg.id))
            await i.response.send_message("Sorteio iniciado!", ephemeral=True)

        button = discord.ui.Button(label="Iniciar Sorteio", style=discord.ButtonStyle.green)
        button.callback = start_callback
        view.add_item(button)

        await interaction.response.send_message(embed=embed, view=view)

# ================= COMANDOS =================
@bot.tree.command(name="sorteio", description="Criar um sorteio")
async def sorteio(interaction: discord.Interaction):
    await interaction.response.send_modal(GiveawayModal())

@bot.tree.command(name="sortearagora", description="Finalizar sorteio pelo ID")
@app_commands.describe(message_id="ID da mensagem do sorteio")
async def sortearagora(interaction: discord.Interaction, message_id: str):
    db = load_db()
    giveaway = db.get(message_id)

    if not giveaway:
        return await interaction.response.send_message("Sorteio não encontrado.", ephemeral=True)

    participants = giveaway["participants"]
    winners_count = giveaway["winners"]

    if len(participants) == 0:
        return await interaction.response.send_message("Sem participantes.", ephemeral=True)

    winners = random.sample(participants, min(len(participants), winners_count))
    mention = ", ".join([f"<@{w}>" for w in winners])

    giveaway["ended"] = True
    save_db(db)

    channel = interaction.channel
    msg = await channel.fetch_message(int(message_id))

    await msg.edit(view=EndView(message_id))

    await interaction.response.send_message(f"🎉 Vencedor(es): {mention}")

# ================= LOOP AUTO =================
@tasks.loop(seconds=30)
async def check_giveaways():
    db = load_db()
    now = datetime.utcnow().timestamp()

    for msg_id, data in db.items():
        if not data["ended"] and now >= data["end_time"]:
            channel = None
            for guild in bot.guilds:
                for ch in guild.text_channels:
                    try:
                        msg = await ch.fetch_message(int(msg_id))
                        channel = ch
                        break
                    except:
                        continue

            if channel:
                participants = data["participants"]
                winners_count = data["winners"]

                if len(participants) > 0:
                    winners = random.sample(participants, min(len(participants), winners_count))
                    mention = ", ".join([f"<@{w}>" for w in winners])
                    await channel.send(f"🎉 Sorteio finalizado! Vencedor(es): {mention}")

                msg = await channel.fetch_message(int(msg_id))
                await msg.edit(view=EndView(msg_id))

            data["ended"] = True

    save_db(db)

# ================= READY =================
@bot.event
async def on_ready():
    await bot.tree.sync()
    check_giveaways.start()
    print(f"Bot online como {bot.user}")

bot.run(TOKEN)